package com.nyit.cashleft;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {

    EditText _loginEmail, _txtFirstName,_txtLastName,_txtPassword;
    Button _btnReg;

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        _loginEmail  = (EditText)findViewById(R.id.loginEmail);
        _txtPassword = (EditText)findViewById(R.id.txtPassword);
        _txtFirstName = (EditText)findViewById(R.id.txtFirstName);
        _txtLastName = (EditText)findViewById(R.id.txtLastName);

        _btnReg = (Button)findViewById(R.id.btnReg);

        openHelper=new DatabaseHelper(this);

        _btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String firstName= _txtFirstName.getText().toString();
                String lastName= _txtLastName.getText().toString();
                String email= _loginEmail.getText().toString();
                String password= _txtPassword.getText().toString();

                db=openHelper.getWritableDatabase();
                insertData(firstName, lastName, email, password);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();

            }
        });

    }

    //database
    public void insertData(String firstName, String lastName, String email, String password){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_2, firstName);
        contentValues.put(DatabaseHelper.COL_3, lastName);
        contentValues.put(DatabaseHelper.COL_4, email);
        contentValues.put(DatabaseHelper.COL_5, password);
        long id = db.insert(DatabaseHelper.TABLE_NAME,null, contentValues);

    }
}
