package com.nyit.cashleft;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddCardsCash extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    private EditText checkingAcc;
    private EditText savingsAcc;
    private EditText routingBank;
    private EditText creditCard;
    private EditText creditDate;
    private EditText creditCvv;
    private EditText cashInput;

    Button btn_AddAccts;
    Button btn_AddCreditCard;
    Button btn_AddCash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_cards_cash);

        openHelper = new DatabaseHelper(this);

        checkingAcc = findViewById(R.id.numCheckingAcc);
        savingsAcc = findViewById(R.id.numSavingsAcc);
        routingBank = findViewById(R.id.numRouting);
        creditCard = findViewById(R.id.numCreditCard);
        creditDate = findViewById(R.id.dateCard);
        creditCvv = findViewById(R.id.numCVV);
        cashInput = findViewById(R.id.numCashInput);

        btn_AddAccts = findViewById(R.id.btnAddAccts);
        btn_AddCreditCard = findViewById(R.id.btnAddCard);
        btn_AddCash = findViewById(R.id.btnAddCash);

        //buttons
        btn_AddAccts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String acctCheckng = checkingAcc.getText().toString();
                String acctSavng = savingsAcc.getText().toString();
                String numRtng = routingBank.getText().toString();

                db = openHelper.getWritableDatabase();
                insertData2(acctCheckng, acctSavng, numRtng);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();

            }
        });

        btn_AddCreditCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _creditCard = creditCard.getText().toString();
                String _creditDate = creditDate.getText().toString();
                String _creditCvv = creditCvv.getText().toString();

                db = openHelper.getWritableDatabase();
                insertData3(_creditCard, _creditDate, _creditCvv);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();

            }
        });

        btn_AddCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String _cashInput = cashInput.getText().toString();

                db = openHelper.getWritableDatabase();
                insertData4(_cashInput);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();

            }
        });
    }

    //DATABASE
    //Bank Accounts
    public void insertData2(String acctCheckng, String acctSavng, String numRtng) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_8, acctCheckng);
        contentValues.put(DatabaseHelper.COL_9, acctSavng);
        contentValues.put(DatabaseHelper.COL_10, numRtng);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);

    }

    //Credit Card
    public void insertData3(String _creditCard, String _creditDate, String _creditCvv) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_11, _creditCard);
        contentValues.put(DatabaseHelper.COL_12, _creditDate);
        contentValues.put(DatabaseHelper.COL_13, _creditCvv);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);

    }

    //Cash
    public void insertData4(String _cashInput) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_14, _cashInput);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }

}
