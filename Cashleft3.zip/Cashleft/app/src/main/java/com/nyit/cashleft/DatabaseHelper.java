package com.nyit.cashleft;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="register.db";
    public static final String TABLE_NAME="register";

    //Columns
    public static final String COL_1="ID";
    public static final String COL_2="FirstName";
    public static final String COL_3="LastName";
    public static final String COL_4="Email";
    public static final String COL_5="Password";
    public static final String COL_6="New Email";
    public static final String COL_7="New Password";
    public static final String COL_8="Checking Account";
    public static final String COL_9="Savings Account";
    public static final String COL_10="Routing Bank";
    public static final String COL_11="Credit Card";
    public static final String COL_12="Credit card date";
    public static final String COL_13="Credit card cvv";
    public static final String COL_14="Cash Input";

    public static final String COL_15="ExpType1";
    public static final String COL_16="ExpType2";
    public static final String COL_17="ExpType3";
    public static final String COL_18="ExpType4";
    public static final String COL_19="ExpType5";
    public static final String COL_20="ExpType6";
    public static final String COL_21="ExpType7";
    public static final String COL_22="ExpType8";
    public static final String COL_23="ExpType9";
    public static final String COL_24="ExpType10";

    public static final String COL_25="ExpAmount1";
    public static final String COL_26="ExpAmount2";
    public static final String COL_27="ExpAmount3";
    public static final String COL_28="ExpAmount4";
    public static final String COL_29="ExpAmount5";
    public static final String COL_30="ExpAmount6";
    public static final String COL_31="ExpAmount7";
    public static final String COL_32="ExpAmount8";
    public static final String COL_33="ExpAmount9";
    public static final String COL_34="ExpAmount10";


    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, 1);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " +TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT, firstName TEXT, lastName TEXT, password TEXT, email TEXT," +
                " newEmail TEXT, newPass TEXT, checking NUM, savings NUM, routing NUM, creditCard NUM, creditDate NUM, creditCvv NUM, cash NUM," +
                " expType TEXT, expAmount NUM)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);//Drop older table is exists
        onCreate(db);

    }
}
