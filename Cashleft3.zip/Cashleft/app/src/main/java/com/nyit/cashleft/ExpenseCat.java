package com.nyit.cashleft;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExpenseCat extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    private EditText exp1, exp2, exp3, exp4, exp5, exp6, exp7, exp8, exp9, exp10;
    private EditText amount1, amount2, amount3, amount4, amount5, amount6, amount7, amount8, amount9, amount10;
    Button btn_ExpType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_cat);

        openHelper = new DatabaseHelper(this);

        exp1  = findViewById(R.id.txtExpCat1);
        exp2  = findViewById(R.id.txtExpCat2);
        exp3  = findViewById(R.id.txtExpCat3);
        exp4  = findViewById(R.id.txtExpCat4);
        exp5  = findViewById(R.id.txtExpCat5);
        exp6  = findViewById(R.id.txtExpCat6);
        exp7  = findViewById(R.id.txtExpCat7);
        exp8  = findViewById(R.id.txtExpCat8);
        exp9  = findViewById(R.id.txtExpCat9);
        exp10  = findViewById(R.id.txtExpCat10);

        amount1 = findViewById(R.id.numExp1);
        amount2 = findViewById(R.id.numExp2);
        amount3 = findViewById(R.id.numExp3);
        amount4 = findViewById(R.id.numExp4);
        amount5 = findViewById(R.id.numExp5);
        amount6 = findViewById(R.id.numExp6);
        amount7 = findViewById(R.id.numExp7);
        amount8 = findViewById(R.id.numExp8);
        amount9 = findViewById(R.id.numExp9);
        amount10 = findViewById(R.id.numExp10);

        btn_ExpType = findViewById(R.id.btnAddExpType);

        btn_ExpType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String _exp1 = exp1.getText().toString();
                String _exp2 = exp2.getText().toString();
                String _exp3 = exp3.getText().toString();
                String _exp4 = exp4.getText().toString();
                String _exp5 = exp5.getText().toString();
                String _exp6 = exp6.getText().toString();
                String _exp7 = exp7.getText().toString();
                String _exp8 = exp8.getText().toString();
                String _exp9 = exp9.getText().toString();
                String _exp10 = exp10.getText().toString();

                String _amount1 = amount1.getText().toString();
                String _amount2 = amount2.getText().toString();
                String _amount3 = amount3.getText().toString();
                String _amount4 = amount4.getText().toString();
                String _amount5 = amount5.getText().toString();
                String _amount6 = amount6.getText().toString();
                String _amount7 = amount7.getText().toString();
                String _amount8 = amount8.getText().toString();
                String _amount9 = amount9.getText().toString();
                String _amount10 = amount10.getText().toString();

                db = openHelper.getWritableDatabase();
                insertData5(_exp1, _exp2, _exp3, _exp4, _exp5, _exp6, _exp7, _exp8, _exp9, _exp10, _amount1,
                        _amount2,_amount3, _amount4, _amount5, _amount6, _amount7, _amount8, _amount9, _amount10);
                Toast.makeText(getApplicationContext(), "Your category expenses have been added!", Toast.LENGTH_LONG).show();

            }
        });

    }

    //database
    public void insertData5(String _exp1, String _exp2, String _exp3, String _exp4, String _exp5, String _exp6, String _exp7,
    String _exp8, String _exp9, String _exp10, String _amount1, String _amount2, String _amount3,  String _amount4,  String _amount5,
    String _amount6, String _amount7,  String _amount8,  String _amount9, String _amount10) {

        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_15, _exp1);
        contentValues.put(DatabaseHelper.COL_16, _exp2);
        contentValues.put(DatabaseHelper.COL_17, _exp3);
        contentValues.put(DatabaseHelper.COL_18, _exp4);
        contentValues.put(DatabaseHelper.COL_19, _exp5);
        contentValues.put(DatabaseHelper.COL_20, _exp6);
        contentValues.put(DatabaseHelper.COL_21, _exp7);
        contentValues.put(DatabaseHelper.COL_22, _exp8);
        contentValues.put(DatabaseHelper.COL_23, _exp9);
        contentValues.put(DatabaseHelper.COL_24, _exp10);

        contentValues.put(DatabaseHelper.COL_25, _amount1);
        contentValues.put(DatabaseHelper.COL_26, _amount2);
        contentValues.put(DatabaseHelper.COL_27, _amount3);
        contentValues.put(DatabaseHelper.COL_28, _amount4);
        contentValues.put(DatabaseHelper.COL_29, _amount5);
        contentValues.put(DatabaseHelper.COL_30, _amount6);
        contentValues.put(DatabaseHelper.COL_31, _amount7);
        contentValues.put(DatabaseHelper.COL_32, _amount8);
        contentValues.put(DatabaseHelper.COL_33, _amount9);
        contentValues.put(DatabaseHelper.COL_34, _amount10);


        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);

    }

}
