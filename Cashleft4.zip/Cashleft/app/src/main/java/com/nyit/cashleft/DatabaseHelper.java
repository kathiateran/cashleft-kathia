package com.nyit.cashleft;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="register.db";
    public static final String TABLE_NAME="register";

    //Columns
    public static final String COL_1="ID";
    public static final String COL_2="FirstName";
    public static final String COL_3="LastName";
    public static final String COL_4="Email";
    public static final String COL_5="Password";
    public static final String COL_6="New Email";
    public static final String COL_7="New Password";

    public static final String COL_8="Debit Card";
    public static final String COL_9="Debit Date";
    public static final String COL_10="Debit Cvv";
    public static final String COL_11="Credit Card";
    public static final String COL_12="Credit Date";
    public static final String COL_13="Credit Cvv";
    public static final String COL_14="Cash Limit";
    public static final String COL_15="Debit Limit";
    public static final String COL_16="Credit Limit";

    public static final String COL_17="ExpType1";
    public static final String COL_18="ExpType2";
    public static final String COL_19="ExpType3";
    public static final String COL_20="ExpType4";
    public static final String COL_21="ExpAmount1";
    public static final String COL_22="ExpAmount2";
    public static final String COL_23="ExpAmount3";
    public static final String COL_24="ExpAmount4";




    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, 1);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " +TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT, firstName TEXT, lastName TEXT, password TEXT, email TEXT," +
                " newEmail TEXT, newPass TEXT, checking NUM, savings NUM, routing NUM, creditCard NUM, creditDate NUM, creditCvv NUM, cash NUM," +
                " expType TEXT, expAmount NUM)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);//Drop older table is exists
        onCreate(db);

    }
}
