package com.nyit.cashleft;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;
    SQLiteOpenHelper openHelper;

    private EditText loginId;
    private EditText password;
    TextView resetLogin;
    TextView resetPassword;
    Button signUp;
    Button login;
    Cursor cursor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();

        loginId  = findViewById(R.id.loginEmail);
        password = findViewById(R.id.loginPsswrd);

        resetLogin = findViewById(R.id.resetLogin);
        resetPassword = findViewById(R.id.resetPassword);

        signUp = findViewById(R.id.btnSignUp);
        login = findViewById(R.id.btnLogin);

        //Does Login
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String _email = loginId.getText().toString();
                String _password = password.getText().toString();
                cursor = db.rawQuery("SELECT * FROM " +DatabaseHelper.TABLE_NAME+ "WHERE " + DatabaseHelper.COL_4 +" =? AND " + DatabaseHelper.COL_5 +"=? ", new String[]{ _email, _password });

                if (cursor != null) {
                    if(cursor.getCount()>0){
                        Toast.makeText(getApplicationContext(),"Login successful!", Toast.LENGTH_LONG).show();
                    }else
                        Toast.makeText(getApplicationContext(), "Wrong login ID or password", Toast.LENGTH_LONG).show();
                }
            }
        });


        //Does SignUp
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
                startActivity(intent);
            }
        });

        //Reset
        resetLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UserProfile.class);
                startActivity(intent);
            }
        });

        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UserProfile.class);
                startActivity(intent);
            }
        });


    }


    }


