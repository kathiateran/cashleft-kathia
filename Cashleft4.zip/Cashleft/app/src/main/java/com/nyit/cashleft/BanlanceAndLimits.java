package com.nyit.cashleft;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BanlanceAndLimits extends AppCompatActivity {


    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    private EditText cardDebit;
    private EditText _dateDebit;
    private EditText _cvvDebit;
    private EditText cardCredit;
    private EditText _dateCredit;
    private EditText _cvvCredit;
    private EditText cashLimit;
    private EditText debitLimit;
    private EditText credLimit;

    Button btn_AddCredCard;
    Button btn_AddDebCard;
    Button btn_SetCashLim;
    Button btn_SetDebLim;
    Button btn_SetCredLim;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banlance_and_limits);

        openHelper = new DatabaseHelper(this);

        cardDebit = findViewById(R.id.numDebitCard);
        _dateDebit = findViewById(R.id.dateDebit);
        _cvvDebit = findViewById(R.id.cvvDebit);
        cardCredit = findViewById(R.id.numCreditCard);
        _dateCredit = findViewById(R.id.dateCredit);
        _cvvCredit = findViewById(R.id.cvvCredit);
        cashLimit = findViewById(R.id.numCashLim);
        debitLimit = findViewById(R.id.numDebitLim);
        credLimit = findViewById(R.id.numCredLim);

        btn_AddDebCard = findViewById(R.id.btnAddDebCard);
        btn_AddCredCard = findViewById(R.id.btnAddCredCard);
        btn_SetCashLim = findViewById(R.id.btnSetCashLim);
        btn_SetDebLim = findViewById(R.id.btnSetDebLim);
        btn_SetCredLim = findViewById(R.id.btnSetCredLim);

        //buttons
        btn_AddDebCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String num_DebitCard = cardDebit.getText().toString();
                String date_Debit = _dateDebit.getText().toString();
                String cvv_Debit = _cvvDebit.getText().toString();

                db = openHelper.getWritableDatabase();
                insertDebitCard(num_DebitCard, date_Debit, cvv_Debit);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();
            }
        });

        btn_AddCredCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String num_CreditCard = cardCredit.getText().toString();
                String date_Credit = _dateCredit.getText().toString();
                String cvv_Credit = _cvvCredit.getText().toString();

                db = openHelper.getWritableDatabase();
                insertCreditCard(num_CreditCard, date_Credit, cvv_Credit);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();
            }
        });

        btn_SetCashLim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cash_limit = cashLimit.getText().toString();

                db = openHelper.getWritableDatabase();
                insertCashLimit(cash_limit);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();
            }
        });

        btn_SetDebLim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String debit_limit = debitLimit.getText().toString();

                db = openHelper.getWritableDatabase();
                insertDebitLimit(debit_limit);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();
            }
        });

        btn_SetCredLim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cred_limit = credLimit.getText().toString();

                db = openHelper.getWritableDatabase();
                insertCreditLimit(cred_limit);
                Toast.makeText(getApplicationContext(), "All Set!", Toast.LENGTH_LONG).show();
            }
        });
    }

    //DATABASE
    //Cards
    public void insertDebitCard(String num_DebitCard, String date_Debit, String cvv_Debit){
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_8, num_DebitCard);
        contentValues.put(DatabaseHelper.COL_9, date_Debit);
        contentValues.put(DatabaseHelper.COL_10, cvv_Debit);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }

    public void insertCreditCard(String num_CreditCard, String date_Credit, String cvv_Credit){
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_11, num_CreditCard);
        contentValues.put(DatabaseHelper.COL_12, date_Credit);
        contentValues.put(DatabaseHelper.COL_13, cvv_Credit);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }

    //Budget Limits
    public void insertCashLimit(String cash_limit) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_14, cash_limit);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }

    public void insertDebitLimit(String debit_limit) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_15, debit_limit);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }

    public void insertCreditLimit(String cred_limit) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_16, cred_limit);

        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);
    }


}
