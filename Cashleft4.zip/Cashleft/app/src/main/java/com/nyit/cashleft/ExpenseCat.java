package com.nyit.cashleft;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.Toast;

public class ExpenseCat extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;

    private EditText exp1, exp2, exp3, exp4;
    private EditText amount1, amount2, amount3, amount4;

    Button btn_ExpType;
    Button btn_addItem;

    private GridLayout cat_Layout;
    DynamicViews userAddedCats;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_cat);

        openHelper = new DatabaseHelper(this);

        exp1  = findViewById(R.id.txtExpCat1);
        exp2  = findViewById(R.id.txtExpCat2);
        exp3  = findViewById(R.id.txtExpCat3);
        exp4  = findViewById(R.id.txtExpCat4);

        amount1 = findViewById(R.id.numExp1);
        amount2 = findViewById(R.id.numExp2);
        amount3 = findViewById(R.id.numExp3);
        amount4 = findViewById(R.id.numExp4);

        btn_ExpType = findViewById(R.id.btnAddExpType);
        btn_ExpType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String _exp1 = exp1.getText().toString();
                String _exp2 = exp2.getText().toString();
                String _exp3 = exp3.getText().toString();
                String _exp4 = exp4.getText().toString();

                String _amount1 = amount1.getText().toString();
                String _amount2 = amount2.getText().toString();
                String _amount3 = amount3.getText().toString();
                String _amount4 = amount4.getText().toString();

                db = openHelper.getWritableDatabase();
                insertData5(_exp1, _exp2, _exp3, _exp4, _amount1, _amount2,_amount3, _amount4);
                Toast.makeText(getApplicationContext(), "Your category expenses have been added!", Toast.LENGTH_LONG).show();
            }
        });

        cat_Layout = (GridLayout)findViewById(R.id.catLayout);
        btn_addItem = (Button)findViewById(R.id.btnAddCategory);

        btn_addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userAddedCats = new DynamicViews(context);
                cat_Layout.addView(userAddedCats.enteredCategory(getApplicationContext()),4);
                cat_Layout.addView(userAddedCats.enteredCatPrice(getApplicationContext()),5);

            }
        });

    }



    //database
    public void insertData5(String _exp1, String _exp2, String _exp3, String _exp4,
                            String _amount1, String _amount2, String _amount3,  String _amount4) {

        ContentValues contentValues = new ContentValues();

        contentValues.put(DatabaseHelper.COL_17, _exp1);
        contentValues.put(DatabaseHelper.COL_18, _exp2);
        contentValues.put(DatabaseHelper.COL_19, _exp3);
        contentValues.put(DatabaseHelper.COL_20, _exp4);

        contentValues.put(DatabaseHelper.COL_21, _amount1);
        contentValues.put(DatabaseHelper.COL_22, _amount2);
        contentValues.put(DatabaseHelper.COL_23, _amount3);
        contentValues.put(DatabaseHelper.COL_24, _amount4);


        long id = db.insert(DatabaseHelper.TABLE_NAME, null, contentValues);

    }

}
